#include <iostream>

using namespace std;

main(){
	float salario, novo_salario;
	
	cout<<"Insira o salario: ";
	cin>>salario;
	
    novo_salario = salario * 0.7;
    
    cout<<"O novo salario eh: ";
    cout<<novo_salario;

	
}