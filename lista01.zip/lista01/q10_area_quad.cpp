#include <iostream>

using namespace std;

main(){
	float base, area;
	
	cout<<"Insira a base: ";
	cin>>base;
		
    area = base * base;
    
    cout<<"A area eh: ";
    cout<<area;

	
}