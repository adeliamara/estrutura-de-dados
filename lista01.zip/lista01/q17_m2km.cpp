
#include <iostream>

using namespace std;

main(){
	float valor_kg, valor_g;
	
	cout<<"Insira em kg: ";
	cin>>valor_kg;
	
	valor_g = valor_kg * 1000;
	
	cout<<"Valor em gramas: ";
	cout<<valor_g;
	
}