#include <iostream>

using namespace std;

main(){
	float metro, centimetro;
	
	cout<<"Insira o valor em m: ";
	cin>>metro;
	
	centimetro = metro * 100;
	
	cout<<"valor em centimetros: ";
	cout<<centimetro;
	
}