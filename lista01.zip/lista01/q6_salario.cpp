//Leia um n�mero inteiro (3 d�gitos) e escreva o inverso do n�mero. (Ex.: num = 532 ; inverso =235)

#include <iostream>

using namespace std;

main(){
	float salario, novo_salario;
	
	cout<<"Insira o salario: ";
	cin>>salario;
	
    novo_salario = salario * 1.25;
    
    cout<<"O novo salario eh: ";
    cout<<novo_salario;

	
}