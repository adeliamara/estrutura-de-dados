#include <iostream>

using namespace std;

main(){
	float base, altura, area;
	
	cout<<"Insira a base: ";
	cin>>base;
		
	cout<<"Insira a altura: ";
	cin>>altura;
	
    area = base * altura;
    
    cout<<"A area eh: ";
    cout<<area;

	
}